package com.onlinestore.data;

import com.onlinestore.model.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DataManager {
    private static final String DATA_FILE = "store_data.bin";

    public static void addProduct(Product product) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE, true))) {
            oos.writeObject(product);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            while (true) {
                Product product = (Product) ois.readObject();
                products.add(product);
            }
        } catch (EOFException e) {
            // End of file
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return products;
    }

    public static void deleteProduct(int productId) {
        List<Product> products = getAllProducts();
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE, false))) {
            for (Product product : products) {
                if (product.getProductId() != productId) {
                    oos.writeObject(product);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Add methods for searching and editing data

    // Example of a method to write data to a binary file (not used directly)
    private static void writeData(List<Product> products) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE, false))) {
            for (Product product : products) {
                oos.writeObject(product);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
