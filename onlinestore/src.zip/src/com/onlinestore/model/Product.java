package com.onlinestore.model;

// Interface for common product properties
interface ProductInterface {
	int getProductId();
	String getName();
	double getPrice();
}

// Interface for stock availability + void body
interface StockAvailability {
	boolean isInStock();
	void setInStock(boolean inStock);
}

public class Product implements ProductInterface {
	private static int nextProductId = 801;
	private int productId;
	private String name;
	private double price;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Product(String name, double price) {
		this.name = name;
		this.price = price;
		this.productId = generateProductId();
	}
	
	private static int generateProductId() {
		return nextProductId++;
	}

	@Override
	public String toString() {
		return "Category : " + this.name + " Product ID : " + this.productId + " Price : " + this.price + " Taka. ";
	}
}

class Clothes extends Product implements StockAvailability {
	private String size;
	private String material;
	private boolean inStock;

	public Clothes(String name, double price, String size, String material, boolean inStock) {

		super(name, price);
		this.size = size;
		this.material = material;
		this.inStock = inStock;
	}
	
	@Override
	public boolean isInStock() {
		return inStock;
	}
	
	@Override
	public void setInStock(boolean inStock) {
		this.inStock = inStock;
	}

	@Override
	public String toString() {
		return super.toString() + "Size : " + this.size + " Material : " + this.material + " In Stock : "
				+ this.inStock;
	}
}

class Shoes extends Product implements StockAvailability {
//	private int productId;
//	private String name;
//	private double price;
	private int size;
	private String brand;
	private boolean inStock;

	public Shoes(int productId, String name, double price, int size, String brand, boolean inStock) {
		super(name, price);
		this.size = size;
		this.brand = brand;
		this.inStock = inStock;
	}
	
	@Override
	public boolean isInStock() {
		return inStock;
	}
	
	@Override
	public void setInStock(boolean inStock) {
		this.inStock = inStock;
	}
	
	@Override
	public String toString() {
		return super.toString() + "Size : " + this.size + " Brand : " + this.brand + " In Stock : " + this.inStock;
	}
}
