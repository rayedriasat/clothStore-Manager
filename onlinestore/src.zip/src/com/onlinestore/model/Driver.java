package com.onlinestore.model;

import java.util.Scanner;

public class Driver {
	public static void main(String[] args) {
		
	}
}
